select * from little_penguins;
