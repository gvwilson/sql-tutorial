select value from generate_series(1, 5);
