select sum(body_mass_g) as total_mass
from penguins;
