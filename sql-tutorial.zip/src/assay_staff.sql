select * from staff;
