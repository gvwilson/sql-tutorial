.read src/create_work_job.sql
.read src/populate_work_job.sql
select * from job;
.print
select * from work;
