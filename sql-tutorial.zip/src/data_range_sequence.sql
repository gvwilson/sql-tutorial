create table temp(
    num integer not null
);
insert into temp values (1), (5);
select value from generate_series(
    (select min(num) from temp),
    (select max(num) from temp)
);
