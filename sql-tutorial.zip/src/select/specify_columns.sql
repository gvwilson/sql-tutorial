select
    species,
    island,
    sex
from little_penguins;
