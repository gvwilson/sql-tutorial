.read src/create_work_job.sql

-- start
select *
from work cross join job;
-- end
