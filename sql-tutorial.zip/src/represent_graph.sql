.read src/lineage_setup.sql
-- [keep]
select * from lineage;
-- [/keep]
