.read src/lineage_setup.sql
-- start
select * from lineage;
-- end
