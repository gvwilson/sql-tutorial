select
    sex,
    body_mass_g                   
from penguins
group by sex;
