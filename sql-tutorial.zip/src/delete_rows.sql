.read src/create_work_job.sql

-- start
delete from work
where person = "tae";

select * from work;
-- end
