select rowid, species, island
from penguins
limit 5;
