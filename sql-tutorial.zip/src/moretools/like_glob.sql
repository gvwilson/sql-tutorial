select
    personal,
    family
from staff
where personal like '%ya%';
