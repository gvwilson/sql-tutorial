.headers on
.mode markdown
select * from little_penguins;
