pip install polars pyarrow adbc-driver-sqlite
