select count(*) as count_star, count(sex) as count_specific
from penguins;
