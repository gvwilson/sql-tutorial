select * from machine;
