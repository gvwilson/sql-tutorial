.read src/create_work_job.sql

-- start
update work
set person = "tae"
where person = "tay";

select * from work;
-- end
