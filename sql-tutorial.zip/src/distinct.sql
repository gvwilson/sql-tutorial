select distinct
    species,
    sex,
    island
from penguins;
