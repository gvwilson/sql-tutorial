select
    species,
    sex,
    island
from penguins
where sex is null;
