select
    flipper_length_mm / 10.0,
    body_mass_g / 1000.0
from penguins
limit 3;
