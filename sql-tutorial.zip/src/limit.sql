select
    species,
    sex,
    island
from penguins
order by species, sex, island
limit 10;
