sqlite3 data/penguins.db
