update work
set person = "tae"
where person = "tay";
