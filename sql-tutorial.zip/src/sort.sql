select
    species,
    sex,
    island
from little_penguins
order by island asc, sex desc;
