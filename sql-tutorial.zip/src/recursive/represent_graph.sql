.read lineage_setup.sql
-- [keep]
select * from lineage;
-- [/keep]
