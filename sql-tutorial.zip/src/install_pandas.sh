pip install pandas
