create role penguin_reader_writer
with login password 'reader_writer';
