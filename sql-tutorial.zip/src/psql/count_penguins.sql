select count(*) from penguins;
