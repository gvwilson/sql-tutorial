revoke update on penguins, little_penguins
to penguin_reader_writer;
