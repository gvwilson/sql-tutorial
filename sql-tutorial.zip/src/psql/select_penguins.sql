select * from penguins limit 10;
