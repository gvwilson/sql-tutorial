psql -d penguins 
