update penguins
set island = 'Atlantis'
where sex = 'MALE' and island = 'Antarctica';
