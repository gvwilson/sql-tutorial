delete from penguins
where island='Antarctica' and sex='MALE';
