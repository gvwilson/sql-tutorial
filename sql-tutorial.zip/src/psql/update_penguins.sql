update penguins
set island = 'Antarctica'
where sex = 'MALE' and island = 'Torgersen';
